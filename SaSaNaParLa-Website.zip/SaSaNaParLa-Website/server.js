const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const session = require("express-session");
const XLSX = require("xlsx");

const app = express();
const PORT = process.env.PORT || 3000;


/* ==================================================
   MONGODB
================================================== */

mongoose
    .connect("mongodb://127.0.0.1:27017/schoolDB")
    .then(() => {
        console.log("MongoDB Connected Successfully");
    })
    .catch((err) => {
        console.error(
            "MongoDB Connection Error:",
            err.message
        );
    });


/* ==================================================
   USER SCHEMA
================================================== */

const userSchema = new mongoose.Schema(
    {
        username: {
            type: String,
            required: true,
            unique: true,
            trim: true
        },

        password: {
            type: String,
            required: true
        },

        role: {
            type: String,
            enum: ["admin", "user"],
            default: "user"
        },

        lastLoginAt: { type: Date, default: null },
        failedLoginAttempts: { type: Number, default: 0 },
        lockUntil: { type: Date, default: null },
        loginHistory: { type: Array, default: [] },

        profile: {
            fullName: {
                type: String,
                default: ""
            },

            email: {
                type: String,
                default: ""
            },

            phone: {
                type: String,
                default: ""
            },

            address: {
                type: String,
                default: ""
            },

            bio: {
                type: String,
                default: ""
            },

            image: {
                type: String,
                default: ""
            }
        }
    },
    {
        timestamps: true
    }
);


/* ==================================================
   SCHOOL SCHEMA
================================================== */

const schoolSchema = new mongoose.Schema({
    schoolName: {
        type: String,
        default: "သာသနပါလ ပရဟိတကျောင်း"
    },

    logo: {
        type: String,
        default: "/images/logo.png"
    },

    heroImage: {
        type: String,
        default: "/images/hero.jpg"
    },

    about: {
        type: String,
        default: ""
    },

    history: {
        type: String,
        default: ""
    },

    // Public contact details shown on the Contact page
    contactAddress: {
        type: String,
        default: ""
    },
    contactPhone: {
        type: String,
        default: ""
    },

    students: {
        type: Array,
        default: []
    },

    donors: {
        type: Array,
        default: []
    },

    buildings: {
        type: Array,
        default: []
    },

    teachers: {
        type: Array,
        default: []
    },

    guides: {
        type: Array,
        default: []
    },

    yearlyStudents: {
        type: Array,
        default: []
    },

    universityPassers: {
        type: Array,
        default: []
    },

    // User-side data visibility controls. These only hide/show data; they do not delete anything.
    dataVisibility: {
        teachers: { type: Boolean, default: true },
        guides: { type: Boolean, default: true },
        students: { type: Boolean, default: true },
        donors: { type: Boolean, default: true },
        yearlyStudents: { type: Boolean, default: true },
        universityPassers: { type: Boolean, default: true }
    },

    photos: {
        type: Array,
        default: []
    },

    attendanceRecords: { type: Array, default: [] },

    videos: { type: Array, default: [] }
});


/* ==================================================
   NEWS SCHEMA
================================================== */

const newsSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },

    description: {
        type: String,
        required: true
    },

    image: {
        type: String,
        default: ""
    },

    date: {
        type: String,
        default: () =>
            new Date().toLocaleDateString()
    },

    likes: {
        type: Number,
        default: 0
    },

    likedBy: {
        type: Array,
        default: []
    },

    comments: {
        type: Array,
        default: []
    }
});


const User = mongoose.model(
    "User",
    userSchema
);

const School = mongoose.model(
    "School",
    schoolSchema
);

const News = mongoose.model(
    "News",
    newsSchema
);


/* ==================================================
   EXPRESS SETTINGS
================================================== */

app.set(
    "view engine",
    "ejs"
);

app.set(
    "views",
    path.join(__dirname, "views")
);

app.use(
    express.static(
        path.join(__dirname, "public")
    )
);

app.use(
    "/uploads",
    express.static(
        path.join(
            __dirname,
            "public/uploads"
        )
    )
);

app.use(
    express.urlencoded({
        extended: true
    })
);

app.use(
    express.json()
);


/* ==================================================
   SESSION
================================================== */

app.use(
    session({
        secret:
            process.env.SESSION_SECRET || "charity-school-secret-2026-change-this",

        resave: false,

        saveUninitialized: false,

        cookie: {
            maxAge:
                24 *
                60 *
                60 *
                1000
        }
    })
);


/* ==================================================
   UPLOAD FOLDER
================================================== */

const uploadDir = path.join(
    __dirname,
    "public/uploads"
);

if (
    !fs.existsSync(uploadDir)
) {
    fs.mkdirSync(
        uploadDir,
        {
            recursive: true
        }
    );
}


/* ==================================================
   MULTER
================================================== */

const storage =
    multer.diskStorage({

        destination: (
            req,
            file,
            cb
        ) => {

            cb(
                null,
                uploadDir
            );

        },

        filename: (
            req,
            file,
            cb
        ) => {

            const ext =
                path.extname(
                    file.originalname
                );

            const filename =
                Date.now() +
                "-" +
                Math.round(
                    Math.random() *
                    1000000000
                ) +
                ext;

            cb(
                null,
                filename
            );

        }

    });


const upload = multer({ storage: storage, limits: { fileSize: 5 * 1024 * 1024 } });

// Video files have a separate 1 GB limit; image upload limits stay unchanged.
const videoUpload = multer({ storage, limits: { fileSize: 1024 * 1024 * 1024 }, fileFilter: (req, file, cb) => {
    if (file.mimetype && file.mimetype.startsWith("video/")) return cb(null, true);
    cb(new Error("Video ဖိုင်သာ တင်နိုင်ပါသည်။"));
} });


/* ==================================================
   DEFAULT SCHOOL DATA
================================================== */

async function getDefaultData() {

    let schoolData =
        await School.findOne();

    if (!schoolData) {

        schoolData =
            await School.create({});

    }

    const fields = [
        "students",
        "donors",
        "buildings",
        "teachers",
        "guides",
        "yearlyStudents",
        "universityPassers",
        "photos"
    ];

    for (
        const field of fields
    ) {

        if (
            !Array.isArray(
                schoolData[field]
            )
        ) {

            schoolData[field] = [];

        }

    }

    return schoolData;
}


/* ==================================================
   CURRENT USER
================================================== */

app.use(
    async (
        req,
        res,
        next
    ) => {

        res.locals.currentUser =
            null;

        if (
            req.session.userId
        ) {

            try {

                const user =
                    await User.findById(
                        req.session.userId
                    );

                if (user) {

                    res.locals.currentUser =
                        user;

                }

            } catch (error) {

                console.error(
                    "Session user error:",
                    error.message
                );

            }

        }

        next();

    }
);


/* ==================================================
   USER AUTH MIDDLEWARE
================================================== */

async function requireUser(
    req,
    res,
    next
) {
    // User-only actions must never accept an Admin session.
    const isLikeRequest = /\/like(?:\?|$)/i.test(req.path);

    if (!req.session.userId) {
        if (isLikeRequest) {
            return res.status(401).json({
                success: false,
                message: "Like ပေးရန် User အကောင့်ဖြင့် Login ဝင်ပါ။",
                loginRequired: true
            });
        }
        return res.redirect("/user_login");
    }

    try {
        const user = await User.findById(req.session.userId);
        if (!user) {
            if (isLikeRequest) {
                return res.status(401).json({
                    success: false,
                    message: "ပြန်လည် Login ဝင်ပါ။",
                    loginRequired: true
                });
            }
            return res.redirect("/user_login");
        }

        if (user.role !== "user") {
            if (isLikeRequest) {
                return res.status(403).json({
                    success: false,
                    message: "Admin အကောင့်ဖြင့် Like ပေး၍မရပါ။ User အကောင့်ဖြင့် Login ဝင်ပါ။",
                    userAccountRequired: true
                });
            }
            return res.status(403).send(
                "ဤလုပ်ဆောင်ချက်အတွက် ပုံမှန် User အကောင့်လိုအပ်ပါသည်။"
            );
        }

        next();
    } catch (error) {
        console.error("User authentication error:", error);
        if (isLikeRequest) {
            return res.status(500).json({
                success: false,
                message: "Server Error"
            });
        }
        return res.status(500).send("Server Error");
    }
}


/* ==================================================
   ADMIN AUTH MIDDLEWARE
================================================== */

async function getPrimaryAdmin() {
    return User.findOne({ role: "admin" }).sort({ createdAt: 1, _id: 1 });
}

async function requireAdmin(
    req,
    res,
    next
) {

    if (
        !req.session.userId
    ) {

        return res.redirect(
            "/admin/login"
        );

    }

    try {

        const user =
            await User.findById(
                req.session.userId
            );

        if (!user) {

            return req.session.destroy(
                () => {

                    res.redirect(
                        "/admin/login"
                    );

                }
            );

        }

        if (user.role !== "admin") {
            return res.status(403).send("Admin access required.");
        }

        next();

    } catch (error) {

        console.error(error);

        res.status(500).send(
            "Admin authentication error."
        );

    }

}


/* ==================================================
   ERROR RENDER
================================================== */

function renderError(
    res,
    view,
    message,
    extra = {}
) {

    return res.render(
        view,
        {
            error: message,
            ...extra
        }
    );

}


/* ==================================================
   HOME
================================================== */

app.get(
    "/",
    async (
        req,
        res
    ) => {

        try {

            const schoolData =
                await getDefaultData();

            const newsList =
                await News
                    .find()
                    .sort({
                        _id: -1
                    });

            const data = {
                ...schoolData.toObject(),
                news: newsList
            };

            res.render(
                "index",
                {
                    data,
                    currentUser:
                        res.locals.currentUser
                }
            );

        } catch (error) {

            console.error(error);

            res.status(500).send(
                "Server Error"
            );

        }

    }
);


/* ==================================================
   ABOUT / HISTORY
================================================== */

app.get(
    "/about",
    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();

            res.render(
                "about",
                {
                    about: d.about
                }
            );

        } catch (error) {

            res.status(500).send(
                "Server Error"
            );

        }

    }
);


app.get(
    "/history",
    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();

            res.render(
                "history",
                {
                    history:
                        d.history
                }
            );

        } catch (error) {

            res.status(500).send(
                "Server Error"
            );

        }

    }
);


/* ==================================================
   PUBLIC DATA PAGES
================================================== */

app.get(
    "/teachers",
    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();

            res.render(
                "teachers",
                {
                    teachers:
                        d.teachers || [],
                    visible: d.dataVisibility?.teachers !== false
                }
            );

        } catch (error) {

            res.status(500).send(
                "Server Error"
            );

        }

    }
);


app.get(
    "/guides",
    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();

            res.render(
                "guides",
                {
                    guides:
                        d.guides || [],
                    visible: d.dataVisibility?.guides !== false
                }
            );

        } catch (error) {

            res.status(500).send(
                "Server Error"
            );

        }

    }
);


app.get(
    "/students",
    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();

            res.render(
                "students",
                {
                    students:
                        d.students || [],
                    visible: d.dataVisibility?.students !== false
                }
            );

        } catch (error) {

            res.status(500).send(
                "Server Error"
            );

        }

    }
);


app.get(
    "/donors",
    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();

            res.render(
                "donors",
                {
                    donors:
                        d.donors || [],
                    visible: d.dataVisibility?.donors !== false
                }
            );

        } catch (error) {

            res.status(500).send(
                "Server Error"
            );

        }

    }
);


app.get(
    "/yearly-students",
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const records = d.yearlyStudents || [];
            const years = [...new Set(records.map(x => String(x.year || "").trim()).filter(Boolean))].sort((a,b) => b.localeCompare(a, undefined, {numeric:true}));
            const year = String(req.query.year || "").trim();
            const q = String(req.query.q || "").trim().toLowerCase();
            const pageSize = 8;
            const requestedPage = Math.max(1, parseInt(req.query.page || "1", 10) || 1);
            const filtered = records.filter(x => {
                const recordYear = String(x.year || "").trim();
                return (!year || recordYear === year) && (!q || Object.values(x).some(v => String(v ?? "").toLowerCase().includes(q)));
            });
            const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
            const page = Math.min(requestedPage, totalPages);
            const pagedRecords = filtered.slice((page - 1) * pageSize, page * pageSize);
            res.render("yearly-students", { records: pagedRecords, years, selectedYear: year, q, page, totalPages, visible: d.dataVisibility?.yearlyStudents !== false });
        } catch (error) { console.error(error); res.status(500).send("Server Error"); }
    }
);

app.get(
    "/university-passers",
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const records = d.universityPassers || [];
            const years = [...new Set(records.map(x => String(x.year || "").trim()).filter(Boolean))].sort((a,b) => b.localeCompare(a, undefined, {numeric:true}));
            const year = String(req.query.year || "").trim();
            const q = String(req.query.q || "").trim().toLowerCase();
            const pageSize = 8;
            const requestedPage = Math.max(1, parseInt(req.query.page || "1", 10) || 1);
            const filtered = records.filter(x => {
                const recordYear = String(x.year || "").trim();
                return (!year || recordYear === year) && (!q || Object.values(x).some(v => String(v ?? "").toLowerCase().includes(q)));
            });
            const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
            const page = Math.min(requestedPage, totalPages);
            const pagedRecords = filtered.slice((page - 1) * pageSize, page * pageSize);
            res.render("university-passers", { records: pagedRecords, years, selectedYear: year, q, page, totalPages, visible: d.dataVisibility?.universityPassers !== false });
        } catch (error) { console.error(error); res.status(500).send("Server Error"); }
    }
);

app.get(
    "/buildings",
    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();

            res.render(
                "buildings",
                {
                    buildings:
                        d.buildings || []
                }
            );

        } catch (error) {

            res.status(500).send(
                "Server Error"
            );

        }

    }
);


app.get(
    "/photos",
    async (
        req,
        res
    ) => {

        try {

            const d = await getDefaultData();
            const currentUser = res.locals.currentUser;
            const userId = currentUser ? String(currentUser._id) : null;

            const photos = (d.photos || []).map((photo) => {
                const likedBy = Array.isArray(photo.likedBy)
                    ? photo.likedBy
                    : [];

                const liked = !!userId && likedBy.some(
                    (person) => String(person.userId) === userId
                );

                return {
                    ...photo.toObject ? photo.toObject() : photo,
                    likes: likedBy.length || Number(photo.likes || 0),
                    liked
                };
            });

            res.render(
                "photos",
                {
                    photos,
                    currentUser
                }
            );

        } catch (error) {

            console.error(error);
            res.status(500).send(
                "Server Error"
            );

        }

    }
);


/* ==================================================
   PUBLIC NEWS PAGE
================================================== */

app.get(
    "/news",
    async (
        req,
        res
    ) => {

        try {

            const newsList =
                await News
                    .find()
                    .sort({ _id: -1 });

            const currentUser = res.locals.currentUser;
            const userId = currentUser ? String(currentUser._id) : null;
            const news = (newsList || []).map(item => {
                const likedBy = Array.isArray(item.likedBy) ? item.likedBy : [];
                return {
                    ...item.toObject(),
                    likes: likedBy.length || Number(item.likes || 0),
                    liked: !!userId && likedBy.some(x => String(x.userId) === userId),
                    comments: Array.isArray(item.comments) ? item.comments : []
                };
            });

            res.render(
                "news",
                {
                    news,
                    currentUser
                }
            );

        } catch (error) {

            console.error(error);

            res.status(500).send(
                "Server Error"
            );

        }

    }
);


/* ==================================================
   USER REGISTER PAGE
================================================== */

app.get(
    "/user_register",
    (
        req,
        res
    ) => {

        res.render(
            "user_register",
            {
                error: null
            }
        );

    }
);


/* ==================================================
   USER REGISTER
   Profile Picture ပါဝင်
================================================== */

app.post(
    "/user_register",

    upload.single("image"),

    async (
        req,
        res
    ) => {

        try {

            const {
                username,
                password,
                confirmPassword,
                fullName,
                email,
                phone,
                address
            } = req.body;


            if (
                !username ||
                !password
            ) {

                return renderError(
                    res,
                    "user_register",
                    "Username နှင့် Password လိုအပ်ပါသည်။"
                );

            }


            if (
                password !==
                confirmPassword
            ) {

                return renderError(
                    res,
                    "user_register",
                    "Password နှစ်ခုမတူပါ။"
                );

            }


            const cleanUsername =
                username.trim();


            const existingUser =
                await User.findOne({
                    username:
                        cleanUsername
                });


            if (existingUser) {

                return renderError(
                    res,
                    "user_register",
                    "Username ရှိပြီးသားဖြစ်နေပါသည်။"
                );

            }


            const hashedPassword =
                await bcrypt.hash(
                    password,
                    10
                );


            let imagePath = "";


            if (req.file) {

                imagePath =
                    "/uploads/" +
                    req.file.filename;

            }


            const user =
                await User.create({

                    username:
                        cleanUsername,

                    password:
                        hashedPassword,

                    role:
                        "user",

                    profile: {

                        fullName:
                            fullName || "",

                        email:
                            email || "",

                        phone:
                            phone || "",

                        address:
                            address || "",

                        image:
                            imagePath

                    }

                });


            user.failedLoginAttempts = 0;
            user.lockUntil = null;
            user.lastLoginAt = new Date();
            user.loginHistory = (user.loginHistory || []).concat([{ at: new Date(), success: true, ip: req.ip }]).slice(-50);
            await user.save();

            req.session.userId =
                user._id;

            req.session.username =
                user.username;

            req.session.role =
                "user";


            req.session.save(
                (error) => {

                    if (error) {

                        console.error(
                            error
                        );

                        return res
                            .status(500)
                            .send(
                                "Session Error"
                            );

                    }

                    res.redirect(
                        "/user_profile"
                    );

                }
            );

        } catch (error) {

            console.error(
                "User Registration Error:",
                error
            );

            res.status(500).send(
                "User Registration Error"
            );

        }

    }
);


/* ==================================================
   USER LOGIN PAGE
================================================== */

app.get(
    "/user_login",
    (
        req,
        res
    ) => {

        res.render(
            "user_login",
            {
                error: null
            }
        );

    }
);


/* ==================================================
   USER LOGIN
================================================== */

app.post(
    "/user_login",
    async (
        req,
        res
    ) => {

        try {

            const username =
                String(
                    req.body.username || ""
                ).trim();

            const password =
                String(
                    req.body.password || ""
                );


            const user =
                await User.findOne({
                    username
                });

            if (user && user.lockUntil && user.lockUntil > new Date()) {
                return renderError(res, "admin/login", "Login ကြိုးစားမှုများလွန်းပါသည်။ ၁၅ မိနစ်အကြာ ပြန်ကြိုးစားပါ။");
            }

            if (!user) {

                return renderError(
                    res,
                    "user_login",
                    "Username သို့မဟုတ် Password မှားနေပါသည်။"
                );

            }


            /*
              Admin account ကို
              User Login မှာ မဝင်စေဘူး။
              Admin Login ကိုသုံးရမယ်။
            */

            if (
                user.role === "admin"
            ) {

                return renderError(
                    res,
                    "user_login",
                    "ဒီ Account က Admin Account ဖြစ်ပါတယ်။ Admin Login ကိုသုံးပါ။"
                );

            }


            const isMatch =
                await bcrypt.compare(
                    password,
                    user.password
                );


            if (!isMatch) {

                return renderError(
                    res,
                    "user_login",
                    "Username သို့မဟုတ် Password မှားနေပါသည်။"
                );

            }


            user.lastLoginAt = new Date();
            await user.save();

            req.session.userId =
                user._id;

            req.session.username =
                user.username;

            req.session.role =
                "user";


            req.session.save(
                (error) => {

                    if (error) {

                        console.error(
                            error
                        );

                        return res
                            .status(500)
                            .send(
                                "Session Error"
                            );

                    }

                    res.redirect(
                        "/user_profile"
                    );

                }
            );

        } catch (error) {

            console.error(
                "User Login Error:",
                error
            );

            res.status(500).send(
                "User Login Error"
            );

        }

    }
);


/* ==================================================
   USER PROFILE
================================================== */

app.get(
    "/user_profile",
    requireUser,
    async (
        req,
        res
    ) => {

        try {

            const user =
                await User.findById(
                    req.session.userId
                );


            if (!user) {

                return res.redirect(
                    "/user_login"
                );

            }


            res.render(
                "user_profile",
                {
                    user
                }
            );

        } catch (error) {

            console.error(error);

            res.status(500).send(
                "Profile Error"
            );

        }

    }
);


/* ==================================================
   USER PROFILE UPDATE
================================================== */

app.post(
    "/user_profile/update",

    requireUser,

    upload.single("image"),

    async (
        req,
        res
    ) => {

        try {

            const user =
                await User.findById(
                    req.session.userId
                );


            if (!user) {

                return res.redirect(
                    "/user_login"
                );

            }


            user.profile.fullName =
                req.body.fullName || "";

            user.profile.email =
                req.body.email || "";

            user.profile.phone =
                req.body.phone || "";

            user.profile.address =
                req.body.address || "";

            user.profile.bio =
                req.body.bio || "";


            if (req.file) {

                user.profile.image =
                    "/uploads/" +
                    req.file.filename;

            }


            await user.save();


            res.redirect(
                "/user_profile"
            );

        } catch (error) {

            console.error(error);

            res.status(500).send(
                "Profile Update Error"
            );

        }

    }
);


/* ==================================================
   USER LOGOUT
================================================== */

app.get(
    "/user_logout",
    (
        req,
        res
    ) => {

        req.session.destroy(
            () => {

                res.redirect("/");

            }
        );

    }
);


/* ==================================================
   SEARCH
================================================== */

app.get(
    "/search",
    async (
        req,
        res
    ) => {

        try {

            const q =
                String(
                    req.query.q || ""
                ).trim();

            const d =
                await getDefaultData();

            const results = [];


            // Search across all filled-in text/numeric fields so the search
            // works even when an admin has used a different field in a record.
            const normalizeSearch = (value) => String(value ?? "")
                .normalize("NFC")
                .toLocaleLowerCase()
                .replace(/[\s\u200B-\u200D\uFEFF]+/g, " ")
                .trim();

            const query = normalizeSearch(q);
            const has = (record) => {
                const collect = (value, key = "") => {
                    if (value == null || ["_id", "__v", "image", "photo", "password", "passwordHash"].includes(key)) return [];
                    if (Array.isArray(value)) return value.flatMap(v => collect(v));
                    if (typeof value === "object") return Object.entries(value).flatMap(([k, v]) => collect(v, k));
                    return [String(value)];
                };
                return collect(record).some(value => normalizeSearch(value).includes(query));
            };


            if (q) {

                if (d.dataVisibility?.teachers !== false) {
                for (
                    const x of
                    d.teachers || []
                ) {

                    if (
                        has(x) ||
                        has(x) ||
                        has(x) ||
                        has(x)
                    ) {

                        results.push({
                            type:
                                "ဆရာ/ဆရာမ",
                            item: x
                        });

                    }

                }
                }

                if (d.dataVisibility?.guides !== false) {
                for (
                    const x of
                    d.guides || []
                ) {

                    if (
                        has(x) ||
                        has(x) ||
                        has(x) ||
                        has(x)
                    ) {

                        results.push({
                            type:
                                "Guide",
                            item: x
                        });

                    }

                }
                }

                if (d.dataVisibility?.students !== false) {
                for (
                    const x of
                    d.students || []
                ) {

                    if (
                        has(x) ||
                        has(x) ||
                        has(x) ||
                        has(x) ||
                        has(x) ||
                        has(x)
                    ) {

                        results.push({
                            type:
                                "ကျောင်းသား/သူ",
                            item: x
                        });

                    }

                }
                }

                if (d.dataVisibility?.donors !== false) {
                for (
                    const x of
                    d.donors || []
                ) {

                    if (
                        has(x) ||
                        has(x) ||
                        has(x) ||
                        has(x) ||
                        has(x) ||
                        has(x)
                    ) {

                        results.push({
                            type:
                                "အလှူရှင်",
                            item: x
                        });

                    }

                }
                }

                for (
                    const x of
                    d.buildings || []
                ) {

                    if (
                        has(x) ||
                        has(x) ||
                        has(x)
                    ) {

                        results.push({
                            type:
                                "ကျောင်းဆောင်",
                            item: x
                        });

                    }

                }

            }


            res.render(
                "search",
                {
                    q,
                    results
                }
            );

        } catch (error) {

            console.error(error);

            res.status(500).send(
                "Search Error"
            );

        }

    }
);


/* ==================================================
   OLD LOGIN / REGISTER LINKS
================================================== */

app.get(
    "/login",
    (
        req,
        res
    ) => {

        res.redirect(
            "/user_login"
        );

    }
);


app.get(
    "/register",
    (req, res) => {
        res.redirect("/user_register");
    }
);


/* ==================================================
   ADMIN LOGIN PAGE
================================================== */

app.get(
    "/admin/login",
    (
        req,
        res
    ) => {

        res.render(
            "admin/login",
            {
                error: null
            }
        );

    }
);


/* ==================================================
   ADMIN LOGIN
================================================== */

app.post(
    "/admin/login",
    async (
        req,
        res
    ) => {

        try {

            const username =
                String(
                    req.body.username || ""
                ).trim();

            const password =
                String(
                    req.body.password || ""
                );


            const user =
                await User.findOne({
                    username
                });

            if (user && user.lockUntil && user.lockUntil > new Date()) {
                return renderError(res, "admin/login", "Login ကြိုးစားမှုများလွန်းပါသည်။ ၁၅ မိနစ်အကြာ ပြန်ကြိုးစားပါ။");
            }

            if (!user) {

                return renderError(
                    res,
                    "admin/login",
                    "Username သို့မဟုတ် Password မှားနေပါသည်။"
                );

            }


            const isMatch =
                await bcrypt.compare(
                    password,
                    user.password
                );


            if (!isMatch) {
                if (user) {
                    user.failedLoginAttempts = (user.failedLoginAttempts || 0) + 1;
                    if (user.failedLoginAttempts >= 5) {
                        user.lockUntil = new Date(Date.now() + 15 * 60 * 1000);
                        user.failedLoginAttempts = 0;
                    }
                    user.loginHistory = (user.loginHistory || []).concat([{ at: new Date(), success: false, ip: req.ip }]).slice(-50);
                    await user.save();
                }
                return renderError(res, "admin/login", "Username သို့မဟုတ် Password မှားနေပါသည်။");
            }


            if (user.role !== "admin") {
                return renderError(res, "admin/login", "Admin အကောင့်ဖြင့်သာ ဝင်ရောက်နိုင်ပါသည်။");
            }


            req.session.userId =
                user._id;

            req.session.username =
                user.username;

            req.session.role =
                "admin";


            req.session.save(
                (error) => {

                    if (error) {

                        console.error(
                            error
                        );

                        return res
                            .status(500)
                            .send(
                                "Session Error"
                            );

                    }

                    res.redirect(
                        "/admin"
                    );

                }
            );

        } catch (error) {

            console.error(error);

            res.status(500).send(
                "Admin Login Error"
            );

        }

    }
);


/* ==================================================
   ADMIN REGISTRATION MANAGEMENT (MAXIMUM TWO ADMINS)
================================================== */

app.get("/admin/register", requireAdmin, (req, res) => res.redirect("/admin/register/change"));

// Admin account deletion: protect the active account and the final administrator.
app.get("/admin/register/delete", requireAdmin, async (req, res) => {
    try {
        const admins = await User.find({ role: "admin" }).select("username profile.fullName createdAt").sort({ createdAt: 1, _id: 1 });
        res.render("admin/delete-admins", { admins, currentAdminId: String(req.session.userId), error: null, success: req.query.success === "1" });
    } catch (error) {
        console.error(error);
        res.status(500).send("Admin Delete Page Error");
    }
});

app.post("/admin/register/delete", requireAdmin, async (req, res) => {
    try {
        const targetId = String(req.body.adminId || "");
        const password = String(req.body.currentPassword || "");
        const currentAdmin = await User.findById(req.session.userId);
        if (!currentAdmin || currentAdmin.role !== "admin") return res.status(403).send("Admin access required.");
        const renderDeletePage = async (error) => {
            const admins = await User.find({ role: "admin" }).select("username profile.fullName createdAt").sort({ createdAt: 1, _id: 1 });
            return res.status(400).render("admin/delete-admins", { admins, currentAdminId: String(req.session.userId), error, success: false });
        };
        if (!password || !(await bcrypt.compare(password, currentAdmin.password))) return await renderDeletePage("သင့်လက်ရှိ Admin Password မှန်ကန်စွာ ထည့်ပါ။");
        if (!targetId || targetId === String(req.session.userId)) return await renderDeletePage("လက်ရှိဝင်ထားသော Admin အကောင့်ကို ကိုယ်တိုင်ဖျက်၍ မရပါ။");
        const targetAdmin = await User.findOne({ _id: targetId, role: "admin" });
        if (!targetAdmin) return await renderDeletePage("ဖျက်မည့် Admin အကောင့်ကို မတွေ့ပါ။");
        const adminCount = await User.countDocuments({ role: "admin" });
        if (adminCount <= 1) return await renderDeletePage("နောက်ဆုံးကျန်ရှိသော Admin အကောင့်ကို ဖျက်၍ မရပါ။");
        await User.deleteOne({ _id: targetAdmin._id, role: "admin" });
        return res.redirect("/admin/register/delete?success=1");
    } catch (error) {
        console.error(error);
        res.status(500).send("Admin Delete Error");
    }
});

app.get("/admin/register/change", requireAdmin, async (req, res) => {
    try {
        const adminUser = await User.findById(req.session.userId);
        const adminCount = await User.countDocuments({ role: "admin" });
        res.render("admin/register", { error: null, adminUser, mode: "change", adminCount });
    } catch (error) { console.error(error); res.status(500).send("Admin Registration Error"); }
});

app.get("/admin/register/add", requireAdmin, async (req, res) => {
    try {
        const adminCount = await User.countDocuments({ role: "admin" });
        res.render("admin/register", { error: null, adminUser: null, mode: "add", adminCount, success: req.query.success === "1" });
    } catch (error) { console.error(error); res.status(500).send("Admin Registration Error"); }
});

app.post("/admin/register", requireAdmin, upload.single("image"), async (req, res) => {
    const mode = req.body.mode === "add" ? "add" : "change";
    const viewData = async (error) => ({ error, mode, adminCount: await User.countDocuments({ role: "admin" }), adminUser: mode === "change" ? await User.findById(req.session.userId) : null });
    try {
        const { username, password, confirmPassword, fullName, email, phone, address, bio } = req.body;
        const cleanUsername = String(username || "").trim();
        if (!cleanUsername) return res.status(400).render("admin/register", await viewData("Username လိုအပ်ပါသည်။"));
        if (!password && mode === "add") return res.status(400).render("admin/register", await viewData("Admin အကောင့်အသစ်အတွက် Password လိုအပ်ပါသည်။"));
        if (password !== confirmPassword) return res.status(400).render("admin/register", await viewData("Password နှစ်ခုမတူပါ။"));
        const duplicate = await User.findOne({ username: cleanUsername, ...(mode === "change" ? { _id: { $ne: req.session.userId } } : {}) });
        if (duplicate) return res.status(400).render("admin/register", await viewData("ဒီ Username ကို အသုံးပြုနေပြီးသားဖြစ်ပါသည်။"));

        if (mode === "add") {
            const count = await User.countDocuments({ role: "admin" });
            if (count >= 2) return res.status(400).render("admin/register", await viewData("Admin အကောင့် ၂ ခု ပြည့်နေပါပြီ။ အကောင့်အသစ် ထပ်ဖွင့်လို့မရပါ။"));
            const admin = new User({ username: cleanUsername, password: await bcrypt.hash(password, 10), role: "admin", profile: { fullName: fullName || "", email: email || "", phone: phone || "", address: address || "", bio: bio || "", image: req.file ? "/uploads/" + req.file.filename : "" } });
            await admin.save();
            return res.redirect("/admin/register/add?success=1");
        }

        const currentAdmin = await User.findById(req.session.userId);
        if (!currentAdmin || currentAdmin.role !== "admin") return res.status(403).send("Admin access required.");
        currentAdmin.username = cleanUsername;
        if (password) currentAdmin.password = await bcrypt.hash(password, 10);
        currentAdmin.profile = { ...(currentAdmin.profile || {}), fullName: fullName || "", email: email || "", phone: phone || "", address: address || "", bio: bio || "", image: req.file ? "/uploads/" + req.file.filename : (currentAdmin.profile?.image || "") };
        await currentAdmin.save();
        req.session.username = currentAdmin.username;
        return res.redirect("/admin");
    } catch (error) {
        console.error(error);
        return res.status(500).send("Admin Registration Error");
    }
});


/* ==================================================
   ADMIN LOGOUT
================================================== */

app.get(
    "/admin/logout",
    (
        req,
        res
    ) => {

        req.session.destroy(
            () => {

                res.redirect(
                    "/admin/login"
                );

            }
        );

    }
);


/* ==================================================
   ADMIN DASHBOARD
================================================== */

app.get(
    "/admin",
    requireAdmin,
    async (
        req,
        res
    ) => {

        try {

            const school =
                await getDefaultData();

            const news =
                await News
                    .find()
                    .sort({
                        _id: -1
                    });


            res.render(
                "admin/dashboard",
                {

                    data: {
                        ...school.toObject(),
                        news
                    },

                    school,

                    news,

                    adminUser:
                        res.locals.currentUser,

                    activeTab: String(req.query.tab || "overview"),

                    imported: String(req.query.imported || ""),

                    visibilitySaved: String(req.query.visibility || "")

                }
            );

        } catch (error) {

            console.error(error);

            res.status(500).send(
                "Dashboard Error"
            );

        }

    }
);


/* ==================================================
   ADMIN PROFILE
================================================== */

app.get(
    "/admin/profile",
    requireAdmin,
    async (
        req,
        res
    ) => {

        try {

            const user =
                await User.findById(
                    req.session.userId
                );

            res.render(
                "admin/profile",
                {
                    user
                }
            );

        } catch (error) {

            res.status(500).send(
                "Admin Profile Error"
            );

        }

    }
);


app.post(
    "/admin/profile/update",

    requireAdmin,

    upload.single("image"),

    async (
        req,
        res
    ) => {

        try {

            const user =
                await User.findById(
                    req.session.userId
                );


            user.profile.fullName =
                req.body.fullName || "";

            user.profile.email =
                req.body.email || "";

            user.profile.phone =
                req.body.phone || "";

            user.profile.address =
                req.body.address || "";

            user.profile.bio =
                req.body.bio || "";


            if (req.file) {

                user.profile.image =
                    "/uploads/" +
                    req.file.filename;

            }


            await user.save();


            res.redirect(
                "/admin/profile"
            );

        } catch (error) {

            res.status(500).send(
                "Admin Profile Update Error"
            );

        }

    }
);


/* ==================================================
   EXCEL IMPORT / TEMPLATE SYSTEM
================================================== */

/* ==================================================
   ADMIN USER DATA VISIBILITY
================================================== */

app.post(
    "/admin/data-visibility",
    requireAdmin,
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const keys = [
                "teachers",
                "guides",
                "students",
                "donors",
                "yearlyStudents",
                "universityPassers"
            ];
            if (!d.dataVisibility) d.dataVisibility = {};
            keys.forEach((key) => {
                d.dataVisibility[key] = req.body[key] === "on";
            });
            d.markModified("dataVisibility");
            await d.save();
            res.redirect("/admin?visibility=saved");
        } catch (error) {
            console.error("Data Visibility Update Error:", error);
            res.status(500).send("Data Visibility Update Error");
        }
    }
);


const EXCEL_CONFIG = {
    teachers: {
        title: "Teacher",
        fields: ["name","position","dateOfBirth","nrc","phone","email","education","address","bio","image"],
        labels: ["Name","Position","Date of Birth","NRC","Phone","Email","Education","Address","Bio","Image URL"]
    },
    guides: {
        title: "Guide",
        fields: ["name","role","dateOfBirth","nrc","phone","experience","address","bio","image"],
        labels: ["Name","Role","Date of Birth","NRC","Phone","Experience","Address","Bio","Image URL"]
    },
    students: {
        title: "Student",
        fields: ["name","dateOfBirth","age","gender","grade","admissionDate","fatherName","motherName","guardianPhone","address","notes","image"],
        labels: ["Name","Date of Birth","Age","Gender","Grade","Admission Date","Father Name","Mother Name","Guardian Phone","Address","Notes","Image URL"]
    },
    donors: {
        title: "Donor",
        fields: ["name","donorType","date","phone","address","amount","item","purpose","notes","image"],
        labels: ["Name","Donor Type","Date","Phone","Address","Amount","Item","Purpose","Notes","Image URL"]
    },
    yearlyStudents: {
        title: "Yearly Students",
        fields: ["year","name","dateOfBirth","age","gender","grade","admissionDate","fatherName","motherName","guardianPhone","address","notes","image"],
        labels: ["Year","Name","Date of Birth","Age","Gender","Grade","Admission Date","Father Name","Mother Name","Guardian Phone","Address","Notes","Image URL"]
    },
    universityPassers: {
        title: "University Matriculation Passers",
        fields: ["year","name","gender","rollNumber","school","result","notes","image"],
        labels: ["Year","Name","Gender","Roll Number","School","Result","Notes","Image URL"]
    }
};

function excelConfig(type) { return EXCEL_CONFIG[type] || null; }

app.get("/admin/excel/:type/template", requireAdmin, (req, res) => {
    const cfg = excelConfig(req.params.type);
    if (!cfg) return res.status(404).send("Excel type not found.");
    const workbook = XLSX.utils.book_new();
    const sheet = XLSX.utils.aoa_to_sheet([cfg.fields, cfg.fields.map(() => "")]);
    XLSX.utils.book_append_sheet(workbook, sheet, "Data");
    const instruction = XLSX.utils.aoa_to_sheet([
        ["Column", "Meaning"],
        ...cfg.fields.map((field, i) => [field, cfg.labels[i]])
    ]);
    XLSX.utils.book_append_sheet(workbook, instruction, "Instructions");
    const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", `attachment; filename="${req.params.type}-template.xlsx"`);
    res.send(buffer);
});

app.post("/admin/excel/:type/import", requireAdmin, upload.single("excelFile"), async (req, res) => {
    try {
        const type = req.params.type;
        const cfg = excelConfig(type);
        if (!cfg) return res.status(404).send("Excel type not found.");
        if (!req.file) return res.status(400).send("Excel file မရွေးရသေးပါ။");

        const workbook = XLSX.readFile(req.file.path, { cellDates: false });
        const sheetName = workbook.SheetNames[0];
        if (!sheetName) return res.status(400).send("Excel sheet မတွေ့ပါ။");
        const sheet = workbook.Sheets[sheetName];
        const rawRows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });
        if (!rawRows.length) return res.status(400).send("Excel file အလွတ်ဖြစ်နေပါသည်။");

        const header = rawRows[0].map(v => String(v).trim());
        const missing = cfg.fields.filter((f, i) => header[i] !== f);
        if (missing.length || header.length !== cfg.fields.length) {
            return res.status(400).send("Excel format မကိုက်ညီပါ။ Official template ကို download လုပ်ပြီး အဲ့ဒီ column အစဉ်အတိုင်း ဖြည့်ပါ။");
        }

        const imported = [];
        for (let i = 1; i < rawRows.length; i++) {
            const row = rawRows[i];
            if (!row.some(v => String(v ?? "").trim() !== "")) continue;
            const record = {};
            cfg.fields.forEach((field, j) => { record[field] = String(row[j] ?? "").trim(); });
            if (!record.name) continue;
            imported.push(record);
        }

        if (!imported.length) return res.status(400).send("ထည့်သွင်းရန် data မတွေ့ပါ။");
        const d = await getDefaultData();
        d[type].push(...imported);
        d.markModified(type);
        await d.save();
        fs.unlink(req.file.path, () => {});
        const tabMap = {
            teachers: "teachers",
            guides: "guides",
            students: "students",
            donors: "donors",
            yearlyStudents: "yearly-students",
            universityPassers: "university-passers"
        };
        const tab = tabMap[type] || "overview";
        res.redirect(`/admin?tab=${tab}&imported=${imported.length}`);
    } catch (error) {
        console.error("Excel import error:", error);
        if (req.file?.path) fs.unlink(req.file.path, () => {});
        res.status(500).send("Excel Import Error");
    }
});

app.get("/admin/excel", requireAdmin, async (req, res) => {
    res.render("admin/excel", { configs: EXCEL_CONFIG, imported: req.query.imported || "" });
});

/* Bulk delete selected records from admin management tables. */
app.post("/admin/bulk-delete/:type", requireAdmin, async (req, res) => {
    const allowed = new Set(["teachers", "guides", "students", "donors", "buildings", "yearlyStudents", "universityPassers"]);
    const type = req.params.type;
    if (!allowed.has(type)) return res.status(400).send("စာရင်းအမျိုးအစား မမှန်ပါ။");
    try {
        const raw = Array.isArray(req.body.indices) ? req.body.indices : [req.body.indices].filter(Boolean);
        const indices = [...new Set(raw.map(Number).filter(n => Number.isInteger(n) && n >= 0))].sort((a,b) => b-a);
        const d = await getDefaultData();
        if (!Array.isArray(d[type])) return res.status(400).send("စာရင်း မတွေ့ပါ။");
        let removed = 0;
        for (const i of indices) if (i < d[type].length) { d[type].splice(i, 1); removed++; }
        d.markModified(type); await d.save();
        const tabs = { teachers: "teachers", guides: "guides", students: "students", donors: "donors", buildings: "buildings", yearlyStudents: "yearly-students", universityPassers: "university-passers" };
        res.redirect(`/admin?tab=${tabs[type]}&deleted=${removed}`);
    } catch (e) { console.error("Bulk delete error:", e); res.status(500).send("ရွေးထားသောစာရင်းများ ဖျက်ရာတွင် အမှားဖြစ်နေပါသည်။"); }
});

app.post("/admin/add-yearly-student", requireAdmin, upload.single("image"), async (req, res) => {
    try {
        const d = await getDefaultData();
        d.yearlyStudents.push({ ...req.body, year: String(req.body.year || "").trim(), image: req.file ? "/uploads/" + req.file.filename : "" });
        d.markModified("yearlyStudents"); await d.save(); res.redirect("/admin?tab=yearly-students");
    } catch (e) { console.error(e); res.status(500).send("Error adding yearly student"); }
});

app.post("/admin/add-university-passer", requireAdmin, upload.single("image"), async (req, res) => {
    try {
        const d = await getDefaultData();
        d.universityPassers.push({ ...req.body, year: String(req.body.year || "").trim(), image: req.file ? "/uploads/" + req.file.filename : "" });
        d.markModified("universityPassers"); await d.save(); res.redirect("/admin?tab=university-passers");
    } catch (e) { console.error(e); res.status(500).send("Error adding university passer"); }
});

app.post("/admin/update-yearly-student/:index", requireAdmin, upload.single("image"), async (req,res)=>{
    try { const d=await getDefaultData(); const i=Number(req.params.index); if(!Number.isInteger(i)||i<0||i>=d.yearlyStudents.length)return res.status(404).send("Record not found"); const old=d.yearlyStudents[i]||{}; const {recordIndex,...fields}=req.body; d.yearlyStudents[i]={...old,...fields,year:String(req.body.year||"").trim(),image:req.file ? "/uploads/" + req.file.filename : (old.image || "")}; d.markModified("yearlyStudents"); await d.save(); res.redirect("/admin?tab=yearly-students"); } catch(e){ console.error(e); res.status(500).send("Update Error"); }
});

app.post("/admin/update-university-passer/:index", requireAdmin, upload.single("image"), async (req,res)=>{
    try { const d=await getDefaultData(); const i=Number(req.params.index); if(!Number.isInteger(i)||i<0||i>=d.universityPassers.length)return res.status(404).send("Record not found"); const old=d.universityPassers[i]||{}; const {recordIndex,...fields}=req.body; d.universityPassers[i]={...old,...fields,year:String(req.body.year||"").trim(),image:req.file ? "/uploads/" + req.file.filename : (old.image || "")}; d.markModified("universityPassers"); await d.save(); res.redirect("/admin?tab=university-passers"); } catch(e){ console.error(e); res.status(500).send("Update Error"); }
});

app.post("/admin/delete-yearly-student/:index", requireAdmin, async (req,res)=>{
    try { const d=await getDefaultData(); const i=Number(req.params.index); if(i<0||i>=d.yearlyStudents.length)return res.status(404).send("Record not found"); d.yearlyStudents.splice(i,1); d.markModified("yearlyStudents"); await d.save(); res.redirect("/admin?tab=yearly-students"); } catch(e){res.status(500).send("Delete Error");}
});

app.post("/admin/delete-university-passer/:index", requireAdmin, async (req,res)=>{
    try { const d=await getDefaultData(); const i=Number(req.params.index); if(i<0||i>=d.universityPassers.length)return res.status(404).send("Record not found"); d.universityPassers.splice(i,1); d.markModified("universityPassers"); await d.save(); res.redirect("/admin?tab=university-passers"); } catch(e){res.status(500).send("Delete Error");}
});

/* ==================================================
   ADMIN SCHOOL INFO
================================================== */

app.post(
    "/admin/update-info",

    requireAdmin,

    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();

            d.about =
                req.body.about || "";

            d.history =
                req.body.history || "";

            await d.save();

            res.redirect(
                "/admin"
            );

        } catch (error) {

            res.status(500).send(
                "Error updating info"
            );

        }

    }
);


app.post(
    "/admin/update-school",

    requireAdmin,

    upload.fields([
        {
            name: "logo",
            maxCount: 1
        },
        {
            name: "heroImage",
            maxCount: 1
        }
    ]),

    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();


            d.schoolName =
                req.body.schoolName ||
                d.schoolName;


            d.about =
                req.body.about ||
                d.about;


            d.history =
                req.body.history ||
                d.history;


            if (
                req.files &&
                req.files.logo &&
                req.files.logo[0]
            ) {

                d.logo =
                    "/uploads/" +
                    req.files.logo[0]
                        .filename;

            }


            if (
                req.files &&
                req.files.heroImage &&
                req.files.heroImage[0]
            ) {

                d.heroImage =
                    "/uploads/" +
                    req.files.heroImage[0]
                        .filename;

            }


            await d.save();


            res.redirect(
                "/admin"
            );

        } catch (error) {

            res.status(500).send(
                "School Update Error"
            );

        }

    }
);


/* ==================================================
   ADD TEACHER
================================================== */

app.post(
    "/admin/add-teacher",

    requireAdmin,

    upload.single("image"),

    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();


            d.teachers.push({

                ...req.body,

                image:
                    req.file
                        ? "/uploads/" +
                          req.file.filename
                        : ""

            });


            d.markModified(
                "teachers"
            );


            await d.save();


            res.redirect(
                "/admin"
            );

        } catch (error) {

            res.status(500).send(
                "Error adding teacher"
            );

        }

    }
);


/* ==================================================
   ADD GUIDE
================================================== */

app.post(
    "/admin/add-guide",

    requireAdmin,

    upload.single("image"),

    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();


            d.guides.push({

                ...req.body,

                image:
                    req.file
                        ? "/uploads/" +
                          req.file.filename
                        : ""

            });


            d.markModified(
                "guides"
            );


            await d.save();


            res.redirect(
                "/admin"
            );

        } catch (error) {

            res.status(500).send(
                "Error adding guide"
            );

        }

    }
);


/* ==================================================
   ADD STUDENT
================================================== */

app.post(
    "/admin/add-student",

    requireAdmin,

    upload.single("image"),

    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();


            d.students.push({

                ...req.body,

                image:
                    req.file
                        ? "/uploads/" +
                          req.file.filename
                        : ""

            });


            d.markModified(
                "students"
            );


            await d.save();


            res.redirect(
                "/admin"
            );

        } catch (error) {

            res.status(500).send(
                "Error adding student"
            );

        }

    }
);


/* ==================================================
   OLD STUDENT ROUTE
================================================== */

app.post(
    "/admin/students",

    requireAdmin,

    upload.single("image"),

    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();


            d.students.push({

                ...req.body,

                image:
                    req.file
                        ? "/uploads/" +
                          req.file.filename
                        : ""

            });


            d.markModified(
                "students"
            );


            await d.save();


            res.redirect(
                "/admin"
            );

        } catch (error) {

            res.status(500).send(
                "Error adding student"
            );

        }

    }
);


/* ==================================================
   ADD DONOR
================================================== */

app.post(
    "/admin/add-donor",

    requireAdmin,

    upload.single("image"),

    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();


            d.donors.push({

                ...req.body,

                image:
                    req.file
                        ? "/uploads/" +
                          req.file.filename
                        : ""

            });


            d.markModified(
                "donors"
            );


            await d.save();


            res.redirect(
                "/admin"
            );

        } catch (error) {

            res.status(500).send(
                "Error adding donor"
            );

        }

    }
);


/* ==================================================
   OLD DONOR ROUTE
================================================== */

app.post(
    "/admin/donors",

    requireAdmin,

    upload.single("image"),

    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();


            d.donors.push({

                ...req.body,

                image:
                    req.file
                        ? "/uploads/" +
                          req.file.filename
                        : ""

            });


            d.markModified(
                "donors"
            );


            await d.save();


            res.redirect(
                "/admin"
            );

        } catch (error) {

            res.status(500).send(
                "Error adding donor"
            );

        }

    }
);


/* ==================================================
   UPDATE / DELETE TEACHER
================================================== */

app.post(
    "/admin/update-teacher/:index",
    requireAdmin,
    upload.single("image"),
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const index = Number(req.params.index);

            if (!Number.isInteger(index) || index < 0 || index >= d.teachers.length) {
                return res.status(404).send("Teacher record not found.");
            }

            const oldRecord = d.teachers[index] || {};
            const { recordIndex, ...fields } = req.body;

            d.teachers[index] = {
                ...oldRecord,
                ...fields,
                image: req.file
                    ? "/uploads/" + req.file.filename
                    : (oldRecord.image || "")
            };

            d.markModified("teachers");
            await d.save();
            res.redirect("/admin");
        } catch (error) {
            console.error(error);
            res.status(500).send("Error updating teacher");
        }
    }
);


app.post(
    "/admin/delete-teacher/:index",
    requireAdmin,
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const index = Number(req.params.index);

            if (!Number.isInteger(index) || index < 0 || index >= d.teachers.length) {
                return res.status(404).send("Teacher record not found.");
            }

            d.teachers.splice(index, 1);
            d.markModified("teachers");
            await d.save();
            res.redirect("/admin");
        } catch (error) {
            console.error(error);
            res.status(500).send("Error deleting teacher");
        }
    }
);


/* ==================================================
   UPDATE / DELETE GUIDE
================================================== */

app.post(
    "/admin/update-guide/:index",
    requireAdmin,
    upload.single("image"),
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const index = Number(req.params.index);

            if (!Number.isInteger(index) || index < 0 || index >= d.guides.length) {
                return res.status(404).send("Guide record not found.");
            }

            const oldRecord = d.guides[index] || {};
            const { recordIndex, ...fields } = req.body;

            d.guides[index] = {
                ...oldRecord,
                ...fields,
                image: req.file
                    ? "/uploads/" + req.file.filename
                    : (oldRecord.image || "")
            };

            d.markModified("guides");
            await d.save();
            res.redirect("/admin");
        } catch (error) {
            console.error(error);
            res.status(500).send("Error updating guide");
        }
    }
);


app.post(
    "/admin/delete-guide/:index",
    requireAdmin,
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const index = Number(req.params.index);

            if (!Number.isInteger(index) || index < 0 || index >= d.guides.length) {
                return res.status(404).send("Guide record not found.");
            }

            d.guides.splice(index, 1);
            d.markModified("guides");
            await d.save();
            res.redirect("/admin");
        } catch (error) {
            console.error(error);
            res.status(500).send("Error deleting guide");
        }
    }
);


/* ==================================================
   UPDATE / DELETE STUDENT
================================================== */

app.post(
    "/admin/update-student/:index",
    requireAdmin,
    upload.single("image"),
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const index = Number(req.params.index);

            if (!Number.isInteger(index) || index < 0 || index >= d.students.length) {
                return res.status(404).send("Student record not found.");
            }

            const oldRecord = d.students[index] || {};
            const { recordIndex, ...fields } = req.body;

            d.students[index] = {
                ...oldRecord,
                ...fields,
                image: req.file
                    ? "/uploads/" + req.file.filename
                    : (oldRecord.image || "")
            };

            d.markModified("students");
            await d.save();
            res.redirect("/admin");
        } catch (error) {
            console.error(error);
            res.status(500).send("Error updating student");
        }
    }
);


app.post(
    "/admin/delete-student/:index",
    requireAdmin,
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const index = Number(req.params.index);

            if (!Number.isInteger(index) || index < 0 || index >= d.students.length) {
                return res.status(404).send("Student record not found.");
            }

            d.students.splice(index, 1);
            d.markModified("students");
            await d.save();
            res.redirect("/admin");
        } catch (error) {
            console.error(error);
            res.status(500).send("Error deleting student");
        }
    }
);


/* ==================================================
   UPDATE / DELETE DONOR
================================================== */

app.post(
    "/admin/update-donor/:index",
    requireAdmin,
    upload.single("image"),
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const index = Number(req.params.index);

            if (!Number.isInteger(index) || index < 0 || index >= d.donors.length) {
                return res.status(404).send("Donor record not found.");
            }

            const oldRecord = d.donors[index] || {};
            const { recordIndex, ...fields } = req.body;

            d.donors[index] = {
                ...oldRecord,
                ...fields,
                image: req.file
                    ? "/uploads/" + req.file.filename
                    : (oldRecord.image || "")
            };

            d.markModified("donors");
            await d.save();
            res.redirect("/admin");
        } catch (error) {
            console.error(error);
            res.status(500).send("Error updating donor");
        }
    }
);


app.post(
    "/admin/delete-donor/:index",
    requireAdmin,
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const index = Number(req.params.index);

            if (!Number.isInteger(index) || index < 0 || index >= d.donors.length) {
                return res.status(404).send("Donor record not found.");
            }

            d.donors.splice(index, 1);
            d.markModified("donors");
            await d.save();
            res.redirect("/admin");
        } catch (error) {
            console.error(error);
            res.status(500).send("Error deleting donor");
        }
    }
);


/* ==================================================
   ADD BUILDING
================================================== */

app.post(
    "/admin/add-building",

    requireAdmin,

    upload.single("image"),

    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();


            d.buildings.push({

                ...req.body,

                image:
                    req.file
                        ? "/uploads/" +
                          req.file.filename
                        : ""

            });


            d.markModified(
                "buildings"
            );


            await d.save();


            res.redirect(
                "/admin"
            );

        } catch (error) {

            res.status(500).send(
                "Error adding building"
            );

        }

    }
);


/* ==================================================
   OLD BUILDING ROUTE
================================================== */

app.post(
    "/admin/buildings",

    requireAdmin,

    upload.single("image"),

    async (
        req,
        res
    ) => {

        try {

            const d =
                await getDefaultData();


            d.buildings.push({

                ...req.body,

                image:
                    req.file
                        ? "/uploads/" +
                          req.file.filename
                        : ""

            });


            d.markModified(
                "buildings"
            );


            await d.save();


            res.redirect(
                "/admin"
            );

        } catch (error) {

            res.status(500).send(
                "Error adding building"
            );

        }

    }
);


/* ==================================================
   UPDATE / DELETE BUILDING
================================================== */

app.post(
    "/admin/update-building/:index",
    requireAdmin,
    upload.single("image"),
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const i = Number(req.params.index);
            if (!Number.isInteger(i) || i < 0 || i >= d.buildings.length) {
                return res.status(404).send("Building not found");
            }
            const old = d.buildings[i] || {};
            d.buildings[i] = {
                ...old,
                name: req.body.name || "",
                detail: req.body.detail || "",
                image: req.file ? "/uploads/" + req.file.filename : (old.image || "")
            };
            d.markModified("buildings");
            await d.save();
            res.redirect("/admin?tab=buildings");
        } catch (error) {
            console.error(error);
            res.status(500).send("Error updating building");
        }
    }
);

app.post(
    "/admin/delete-building/:index",
    requireAdmin,
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const i = Number(req.params.index);
            if (!Number.isInteger(i) || i < 0 || i >= d.buildings.length) {
                return res.status(404).send("Building not found");
            }
            d.buildings.splice(i, 1);
            d.markModified("buildings");
            await d.save();
            res.redirect("/admin?tab=buildings");
        } catch (error) {
            console.error(error);
            res.status(500).send("Error deleting building");
        }
    }
);


/* ==================================================
   VIDEO LIBRARY + ADMIN LOGIN HISTORY
================================================== */
app.get("/videos", async (req, res) => {
    try { const d = await getDefaultData(); const currentUser = req.session.userId ? await User.findById(req.session.userId).select("username role profile") : null;
        res.render("videos", { videos: (d.videos || []).slice().reverse(), currentUser });
    } catch (e) { console.error(e); res.status(500).send("Video များဖွင့်မရပါ။"); }
});
app.post("/admin/videos", requireAdmin, videoUpload.single("video"), async (req, res) => {
    try {
        if (!req.file) return res.status(400).send("Video ဖိုင်ရွေးပေးပါ။ (အများဆုံး 1 GB)");
        const d = await getDefaultData();
        d.videos.push({ title: String(req.body.title || req.file.originalname).trim(), url: "/uploads/" + req.file.filename, filename: req.file.filename, size: req.file.size, createdAt: new Date() });
        d.markModified("videos"); await d.save(); res.redirect("/admin?tab=videos");
    } catch (e) { console.error("Video upload error:", e); res.status(500).send("Video တင်ရာတွင် အမှားဖြစ်နေပါသည်။"); }
});
app.post("/admin/videos/:index/delete", requireAdmin, async (req, res) => {
    try { const d = await getDefaultData(); const i = Number(req.params.index); if (!Number.isInteger(i) || !d.videos[i]) return res.status(404).send("Video မတွေ့ပါ။");
        const url = d.videos[i].url || ""; if (url.startsWith("/uploads/")) { const f = path.join(__dirname, "public", url.replace(/^\/uploads\//, "uploads/")); if (fs.existsSync(f)) fs.unlinkSync(f); }
        d.videos.splice(i, 1); d.markModified("videos"); await d.save(); res.redirect("/admin?tab=videos");
    } catch (e) { console.error(e); res.status(500).send("Video ဖျက်မရပါ။"); }
});
app.get("/admin/user-logins", requireAdmin, async (req, res) => {
    try { const users = await User.find({ role: "user" }).select("username profile lastLoginAt").sort({ lastLoginAt: -1, username: 1 }); res.render("admin/user-logins", { users }); }
    catch (e) { console.error(e); res.status(500).send("Login မှတ်တမ်းဖွင့်မရပါ။"); }
});

/* ==================================================
   PHOTO MANAGEMENT
================================================== */

app.post(
    "/admin/photos",
    requireAdmin,
    upload.single("photo"),
    async (req, res) => {
        try {
            const d = await getDefaultData();

            if (!req.file) {
                return res.status(400).send("ဓာတ်ပုံရွေးပေးပါ။");
            }

            const url = "/uploads/" + req.file.filename;

            d.photos.push({
                title: req.body.title || "",
                url,
                image: url,
                likes: 0,
                likedBy: []
            });

            d.markModified("photos");
            await d.save();

            res.redirect("/admin");
        } catch (error) {
            console.error("Error uploading photo:", error);
            res.status(500).send("Error uploading photo");
        }
    }
);

/* EDIT PHOTO */
app.post(
    "/admin/photos/:index/edit",
    requireAdmin,
    upload.single("photo"),
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const i = Number(req.params.index);

            if (!Number.isInteger(i) || !d.photos[i]) {
                return res.status(404).send("Photo not found");
            }

            const oldUrl = d.photos[i].url || d.photos[i].image || "";

            d.photos[i].title = req.body.title || "";

            if (req.file) {
                const newUrl = "/uploads/" + req.file.filename;
                d.photos[i].url = newUrl;
                d.photos[i].image = newUrl;

                if (oldUrl.startsWith("/uploads/")) {
                    const oldFile = path.join(
                        __dirname,
                        "public",
                        oldUrl.replace(/^\/uploads\//, "uploads/")
                    );
                    if (fs.existsSync(oldFile)) {
                        fs.unlinkSync(oldFile);
                    }
                }
            }

            d.markModified("photos");
            await d.save();

            res.redirect("/admin");
        } catch (error) {
            console.error("Error editing photo:", error);
            res.status(500).send("Error editing photo");
        }
    }
);

/* DELETE PHOTO */
app.post(
    "/admin/photos/:index/delete",
    requireAdmin,
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const i = Number(req.params.index);

            if (!Number.isInteger(i) || !d.photos[i]) {
                return res.status(404).send("Photo not found");
            }

            const oldUrl = d.photos[i].url || d.photos[i].image || "";

            if (oldUrl.startsWith("/uploads/")) {
                const oldFile = path.join(
                    __dirname,
                    "public",
                    oldUrl.replace(/^\/uploads\//, "uploads/")
                );
                if (fs.existsSync(oldFile)) {
                    fs.unlinkSync(oldFile);
                }
            }

            d.photos.splice(i, 1);
            d.markModified("photos");
            await d.save();

            res.redirect("/admin");
        } catch (error) {
            console.error("Error deleting photo:", error);
            res.status(500).send("Error deleting photo");
        }
    }
);

/* ==================================================
   NEWS ADD / UPDATE / DELETE
================================================== */

app.post(
    "/admin/add-news",
    requireAdmin,
    upload.single("newsImage"),
    async (req, res) => {
        try {
            await News.create({
                title: req.body.title || "",
                description: req.body.description || req.body.content || "",
                image: req.file ? "/uploads/" + req.file.filename : "",
                likes: 0,
                likedBy: [],
                comments: []
            });
            res.redirect("/admin?tab=news");
        } catch (error) {
            console.error(error);
            res.status(500).send("Add News Error");
        }
    }
);

app.post(
    "/admin/update-news/:id",
    requireAdmin,
    upload.single("newsImage"),
    async (req, res) => {
        try {
            const item = await News.findById(req.params.id);
            if (!item) return res.status(404).send("News not found");
            const oldImage = item.image || "";
            item.title = req.body.title || "";
            item.description = req.body.description || "";
            if (req.file) {
                item.image = "/uploads/" + req.file.filename;
                if (oldImage.startsWith("/uploads/")) {
                    const oldFile = path.join(__dirname, "public", oldImage.replace(/^\/uploads\//, "uploads/"));
                    if (fs.existsSync(oldFile)) fs.unlinkSync(oldFile);
                }
            }
            await item.save();
            res.redirect("/admin?tab=news");
        } catch (error) {
            console.error(error);
            res.status(500).send("Update News Error");
        }
    }
);

app.post(
    "/admin/delete-news/:id",
    requireAdmin,
    async (req, res) => {
        try {
            const item = await News.findById(req.params.id);
            if (!item) return res.status(404).send("News not found");
            if (item.image && item.image.startsWith("/uploads/")) {
                const file = path.join(__dirname, "public", item.image.replace(/^\/uploads\//, "uploads/"));
                if (fs.existsSync(file)) fs.unlinkSync(file);
            }
            await News.deleteOne({ _id: item._id });
            res.redirect("/admin?tab=news");
        } catch (error) {
            console.error(error);
            res.status(500).send("Delete News Error");
        }
    }
);

/* NEWS LIKE - ONE LIKE PER USER PER NEWS */
app.post(
    "/news/:id/like",
    requireUser,
    async (req, res) => {
        try {
            const item = await News.findById(req.params.id);
            const user = await User.findById(req.session.userId);
            if (!item || !user) return res.status(404).json({ success: false, message: "News not found" });
            if (!Array.isArray(item.likedBy)) item.likedBy = [];
            const userId = String(user._id);
            if (item.likedBy.some(x => String(x.userId) === userId)) {
                return res.json({ success: true, alreadyLiked: true, likes: item.likedBy.length });
            }
            item.likedBy.push({
                userId: user._id,
                username: user.username || "",
                fullName: user.profile?.fullName || "",
                image: user.profile?.image || "",
                likedAt: new Date()
            });
            item.likes = item.likedBy.length;
            await item.save();
            res.json({ success: true, alreadyLiked: false, likes: item.likes });
        } catch (error) {
            console.error("News like error:", error);
            res.status(500).json({ success: false, message: "Server Error" });
        }
    }
);

/* NEWS COMMENT */
app.post(
    "/news/:id/comment",
    requireUser,
    async (req, res) => {
        try {
            const item = await News.findById(req.params.id);
            const user = await User.findById(req.session.userId);
            const text = String(req.body.comment || "").trim();
            if (!item || !user) return res.status(404).send("News not found");
            if (!text) return res.redirect("/news?open=" + encodeURIComponent(String(item._id)) + "#news-" + item._id);
            if (!Array.isArray(item.comments)) item.comments = [];
            item.comments.push({
                userId: user._id,
                username: user.username || "",
                fullName: user.profile?.fullName || user.username || "",
                image: user.profile?.image || "",
                text,
                createdAt: new Date()
            });
            await item.save();
            res.redirect("/news?open=" + encodeURIComponent(String(item._id)) + "#news-" + item._id);
        } catch (error) {
            console.error("News comment error:", error);
            res.status(500).send("Comment Error");
        }
    }
);


/* ==================================================
   PHOTO LIKE - ONE LIKE PER USER PER PHOTO
================================================== */

app.post(
    "/photos/:index/like",
    requireUser,
    async (req, res) => {
        try {
            const d = await getDefaultData();
            const i = Number(req.params.index);

            if (!Number.isInteger(i) || !d.photos[i]) {
                return res.status(404).json({
                    success: false,
                    message: "Photo not found"
                });
            }

            const user = await User.findById(req.session.userId);

            if (!user) {
                return res.status(401).json({
                    success: false,
                    message: "Login required"
                });
            }

            const photo = d.photos[i];

            if (!Array.isArray(photo.likedBy)) {
                photo.likedBy = [];
            }

            const userId = String(user._id);
            const alreadyLiked = photo.likedBy.some(
                (person) => String(person.userId) === userId
            );

            if (alreadyLiked) {
                return res.json({
                    success: true,
                    alreadyLiked: true,
                    likes: photo.likedBy.length
                });
            }

            photo.likedBy.push({
                userId: user._id,
                username: user.username || "",
                fullName: user.profile?.fullName || "",
                email: user.profile?.email || "",
                phone: user.profile?.phone || "",
                address: user.profile?.address || "",
                image: user.profile?.image || "",
                likedAt: new Date()
            });

            photo.likes = photo.likedBy.length;
            d.markModified("photos");
            await d.save();

            res.json({
                success: true,
                alreadyLiked: false,
                likes: photo.likes
            });
        } catch (error) {
            console.error("Photo like error:", error);
            res.status(500).json({
                success: false,
                message: "Server Error"
            });
        }
    }
);

/* ==================================================
   ADMIN TOOLS: selectable exports, backup, security, reports and print
================================================== */
const restoreUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024 } });

const ADMIN_LIST_CONFIG = {
  students: { title: "ကျောင်းသားစာရင်း", sheet: "Students" },
  teachers: { title: "ဆရာ/ဆရာမစာရင်း", sheet: "Teachers" },
  guides: { title: "Guide စာရင်း", sheet: "Guides" },
  yearlyStudents: { title: "နှစ်အလိုက် ကျောင်းသားစာရင်း", sheet: "YearlyStudents" },
  universityPassers: { title: "တက္ကသိုလ်ဝင်တန်း အောင်မြင်သူစာရင်း", sheet: "UniversityPassers" },
  donors: { title: "အလှူရှင်စာရင်း", sheet: "Donors" }
};
function selectedAdminLists(value) {
  const requested = String(value || "").split(",").map(x => x.trim()).filter(Boolean);
  return [...new Set(requested)].filter(key => Object.prototype.hasOwnProperty.call(ADMIN_LIST_CONFIG, key));
}
function adminListRows(list) {
  return (Array.isArray(list) ? list : []).map(item => {
    if (item && typeof item.toObject === "function") item = item.toObject();
    if (!item || typeof item !== "object") return { "တန်ဖိုး": String(item ?? "") };
    const row = {};
    for (const [key, value] of Object.entries(item)) {
      if (key.startsWith("_") || key === "__v" || value === undefined || typeof value === "function") continue;
      row[key] = value === null ? "" : (typeof value === "object" ? JSON.stringify(value) : value);
    }
    return row;
  });
}
app.get("/admin/reports", requireAdmin, async (req, res) => {
  try {
    const d = await getDefaultData();
    const data = {};
    for (const key of Object.keys(ADMIN_LIST_CONFIG)) data[key] = (d[key] || []).map(x => x && typeof x.toObject === "function" ? x.toObject() : x);
    res.render("admin/reports", { configs: ADMIN_LIST_CONFIG, data, selected: selectedAdminLists(req.query.type)[0] || "students" });
  } catch (e) { console.error(e); res.status(500).send("Reports Error"); }
});
app.get("/admin/export/lists", requireAdmin, (req, res) => res.render("admin/export-lists", { configs: ADMIN_LIST_CONFIG, error: null }));
app.get("/admin/export/lists.xlsx", requireAdmin, async (req, res) => {
  try {
    const selected = selectedAdminLists(req.query.types);
    if (!selected.length) return res.status(400).send("အနည်းဆုံး စာရင်းတစ်ခု ရွေးပါ။");
    const d = await getDefaultData();
    const wb = XLSX.utils.book_new();
    for (const key of selected) {
      const rows = adminListRows(d[key] || []);
      const ws = rows.length ? XLSX.utils.json_to_sheet(rows) : XLSX.utils.aoa_to_sheet([["စာရင်းအချက်အလက် မရှိပါ"]]);
      XLSX.utils.book_append_sheet(wb, ws, ADMIN_LIST_CONFIG[key].sheet.slice(0,31));
    }
    const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
    res.setHeader("Content-Disposition", 'attachment; filename="school-selected-lists.xlsx"');
    res.type("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet").send(buf);
  } catch (e) { console.error(e); res.status(500).send("Excel Export Error"); }
});
app.get("/admin/print", requireAdmin, (req, res) => res.render("admin/print-select", { configs: ADMIN_LIST_CONFIG }));
app.get("/admin/print/lists", requireAdmin, async (req, res) => {
  try {
    const selected = selectedAdminLists(req.query.types);
    if (!selected.length) return res.redirect("/admin/print");
    const d = await getDefaultData();
    const lists = selected.map(key => ({ key, title: ADMIN_LIST_CONFIG[key].title, rows: adminListRows(d[key] || []) }));
    res.render("admin/print-lists", { lists, date: new Date().toLocaleDateString("en-CA") });
  } catch (e) { console.error(e); res.status(500).send("Print Error"); }
});

app.get("/admin/export/students.xlsx", requireAdmin, async (req, res) => {
  try {
    const d = await getDefaultData();
    const rows = (d.students || []).map((s, i) => ({
      "စဉ်": i + 1, "အမည်": s.name || s.studentName || "", "အတန်း": s.grade || s.class || s.category || "",
      "ကျား/မ": s.gender || "", "အသက်": s.age || "", "မွေးသက္ကရာဇ်": s.dateOfBirth || "",
      "ကျောင်းဝင်ရက်": s.admissionDate || "", "အုပ်ထိန်းသူဖုန်း": s.guardianPhone || s.phone || "",
      "လိပ်စာ": s.address || "", "မှတ်ချက်": s.notes || ""
    }));
    const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), "Students");
    const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
    res.setHeader("Content-Disposition", 'attachment; filename="school-students.xlsx"');
    res.type("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet").send(buf);
  } catch (e) { console.error(e); res.status(500).send("Excel Export Error"); }
});

app.get("/admin/backup", requireAdmin, (req, res) => res.render("admin/backup", { error: null, success: req.query.success === "1" }));
app.get("/admin/backup/download", requireAdmin, async (req, res) => {
  try {
    const [school, users, news] = await Promise.all([School.findOne().lean(), User.find({}).lean(), News.find({}).lean()]);
    const payload = { exportedAt: new Date().toISOString(), warning: "Keep this backup private; it contains password hashes and school data.", school, users, news };
    res.setHeader("Content-Disposition", 'attachment; filename="school-backup-' + new Date().toISOString().slice(0,10) + '.json"');
    res.type("application/json").send(JSON.stringify(payload, null, 2));
  } catch (e) { console.error(e); res.status(500).send("Backup Error"); }
});
app.post("/admin/backup/restore", requireAdmin, restoreUpload.single("backupFile"), async (req, res) => {
  try {
    const admin = await User.findById(req.session.userId);
    if (!admin || !(await bcrypt.compare(String(req.body.password || ""), admin.password))) return res.status(400).render("admin/backup", { error: "လက်ရှိ Admin Password မှန်ကန်စွာထည့်ပါ။", success: false });
    if (!req.file) return res.status(400).render("admin/backup", { error: "Backup JSON ဖိုင်ရွေးပါ။", success: false });
    const data = JSON.parse(req.file.buffer.toString("utf8"));
    if (!data || !data.school || !Array.isArray(data.users) || !Array.isArray(data.news)) throw new Error("Invalid backup format");
    // Restore school content only; never overwrite admin credentials through an uploaded file.
    const schoolData = { ...data.school }; delete schoolData._id; delete schoolData.__v;
    await School.findOneAndUpdate({}, schoolData, { upsert: true, new: true, setDefaultsOnInsert: true });
    await News.deleteMany({}); if (data.news.length) await News.insertMany(data.news.map(n => { const x={...n}; delete x._id; delete x.__v; return x; }));
    res.redirect("/admin/backup?success=1");
  } catch (e) { console.error("Restore error:", e); res.status(400).render("admin/backup", { error: "Backup ဖိုင်မမှန်ပါ သို့မဟုတ် Restore မအောင်မြင်ပါ။ မူလ Database ကိုအရင် Backup လုပ်ထားပါ။", success: false }); }
});

app.get("/admin/security", requireAdmin, async (req, res) => {
  const admin = await User.findById(req.session.userId).select("username loginHistory failedLoginAttempts lockUntil");
  res.render("admin/security", { admin, error: null, success: req.query.success === "1" });
});
app.post("/admin/security/password", requireAdmin, async (req, res) => {
  try {
    const admin = await User.findById(req.session.userId);
    const { currentPassword, newPassword, confirmPassword } = req.body;
    const fail = async error => { const a = await User.findById(req.session.userId).select("username loginHistory failedLoginAttempts lockUntil"); return res.status(400).render("admin/security", { admin: a, error, success: false }); };
    if (!await bcrypt.compare(String(currentPassword || ""), admin.password)) return fail("လက်ရှိ Password မှားနေပါသည်။");
    if (String(newPassword || "").length < 8) return fail("Password အသစ်ကို အနည်းဆုံး ၈ လုံးထားပါ။");
    if (newPassword !== confirmPassword) return fail("Password အသစ်နှစ်ခု မတူပါ။");
    admin.password = await bcrypt.hash(newPassword, 10); admin.loginHistory = (admin.loginHistory || []).concat([{ at: new Date(), success: true, ip: req.ip, event: "password_changed" }]).slice(-50); await admin.save();
    res.redirect("/admin/security?success=1");
  } catch(e) { console.error(e); res.status(500).send("Password Change Error"); }
});

app.get("/admin/print/students", requireAdmin, async (req, res) => {
  const d = await getDefaultData();
  res.render("admin/print-students", { students: d.students || [], date: new Date().toLocaleDateString("en-CA") });
});

/* ==================================================
   PUBLIC CONTACT PAGE
================================================== */
app.get("/contact", async (req, res) => {
    try {
        const d = await getDefaultData();
        res.render("contact", {
            contactAddress: String(d.contactAddress || "").trim(),
            contactPhone: String(d.contactPhone || "").trim()
        });
    } catch (error) {
        console.error("Contact page error:", error);
        res.status(500).send("Contact page ကို ဖွင့်မရပါ။ Server log ကို စစ်ဆေးပါ။");
    }
});

/* ==================================================
   404
================================================== */

app.use(
    (
        req,
        res
    ) => {

        res
            .status(404)
            .send(
                "Page not found: " +
                req.originalUrl
            );

    }
);


/* ==================================================
   START SERVER
================================================== */

app.listen(
    PORT,
    () => {

        console.log(
            `Server running on http://localhost:${PORT}`
        );

    }
);