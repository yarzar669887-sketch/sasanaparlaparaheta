CHARITY SCHOOL WEBSITE - SELECTABLE LIST TOOLS

Changes in this revision:
- Other opens as a side flyout; tools are no longer displayed as a long list in the sidebar.
- Removed Attendance from the visible UI and removed its routes from this version.
- Reports page lets the admin select one of six lists and view a Pie/Doughnut or Bar chart based on available fields.
- Excel Export lets the admin select any combination of six lists; each selected list becomes a separate worksheet in one XLSX workbook.
- Print/PDF lets the admin select any combination of six lists and prints only those selected lists. Use the browser Print dialog to Save as PDF.
- The six selectable lists are Students, Teachers, Guides, Yearly Students, University Passers, and Donors.
- Existing Backup/Restore and Admin Security tools are kept.

Security notes:
- Backup JSON may contain password hashes and personal data; keep it private.
- Test all database actions against a backup before production use.
- MongoDB connection remains configured to mongodb://127.0.0.1:27017/schoolDB as in the original project.
- For production, set SESSION_SECRET to a long random secret in the environment.

Testing note: JavaScript syntax and EJS template parsing should be checked before deployment; live MongoDB behavior is not verified in this environment.
