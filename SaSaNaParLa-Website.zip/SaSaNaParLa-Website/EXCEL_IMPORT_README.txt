CHARITY SCHOOL - ADMIN / EXCEL UPDATE

1. Extract the project.
2. Open terminal in the project folder.
3. Run: npm install
4. Make sure MongoDB is running.
5. Run: node server.js

IMPORTANT:
- This version uses the xlsx npm package for Excel import/template generation.
- Admin account is restricted to the primary admin account. Public users cannot open /admin/register.
- /register now goes to normal user registration.
- Admin Profile is available from the dashboard.
- Excel Import supports teachers, guides, students, donors, yearly students and university matriculation passers.
- Use the official Template Download. Keep the Data sheet column names/order unchanged.
- The Instructions sheet explains each column.
- Year fields are stored as text strings.
